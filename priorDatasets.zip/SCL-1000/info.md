# SCL-1000 Info

**INFO**  
First File: SCL00020  
Japanese Words: 1464  
Japanese Char: 46003  
English Words: NA  
English Char: NA  

**First Lines of SCL Matching This Criteria:**
- Max Lines: 1,000
- Min Japanese Characters: 8
- Exclude lines with only names (Can tell because no hiragana characters)
- Exclude lines with non-ASCII characters in the translation

**Attributions:**
- NICT Corpus - https://github.com/venali/BilingualCorpus