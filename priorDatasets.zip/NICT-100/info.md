# NICT-100 Info

**INFO**  
Lines: 105
Japanese Words: 133  
Japanese Char: 4785  
English Words: 2731  
English Char: 16778  

**Prompts**  
GPT-3.5 Turbo: "translate ＿＿＿＿＿ into English without explanation"  
Gemini-1.5 Flash: "translate ＿＿＿＿＿ into English without explanation"　　

**First Lines of the NICT Bilingual Corpus Matching This Criteria:**
- Max Lines: 1,000 (Margin of Error 15)
- Min Japanese Characters: 8
- Min English Words: 6
- Exclude lines with only names
    - Can tell because no hiragana characters
    - と and や not included, because on their own, they mean 'and'
    - の not included because it means 'of' on its own
- Exclude lines with non-ASCII characters in the translation
  
Files:  
*['SCL 15', 'BDS 15', 'BLD 15', 'CLT 15', 'EPR 15', 'FML 15', 'GNM 15', 'HST 15', 'LTT 15', 'PNM 15', 'RLW 15', 'ROD 15', 'SAT 15', 'SNT 15', 'TTL 15']*  
Char:  
*[360, 370, 492, 342, 243, 190, 203, 452, 283, 414, 351, 243, 267, 252, 323]*

**Attributions:**
- NICT Corpus - https://github.com/venali/BilingualCorpus