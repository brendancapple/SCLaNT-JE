# NICT-1000-1 Info

**INFO**  
Lines: 1005
Japanese Words: 1234
Japanese Char: 52623  
English Words: 27615  
English Char: 170059  

**Prompts**
GPT-3.5 Turbo: "translate <text> into English without explanation"
Gemini-1.5 Flash: "translate <text> without explanation"

**First Lines of the NICT Bilingual Corpus Matching This Criteria:**
- Max Lines: 1,000 (Margin of Error 15)
- Min Japanese Characters: 8
- Min English Words: 6
- Exclude lines with only names (Can tell because no hiragana characters--と and や not included, because on their own, they mean 'and')
- Exclude lines with non-ASCII characters in the translation
  
Files:  
*['SCL 35', 'SCL 36', 'BDS 1', 'BDS 2', 'BLD 1', 'CLT 1', 'CLT 2', 'EPR 1', 'FML 1', 'FML 2', 'FML 3', 'GNM 1', 'GNM 2', 'HST 1', 'LTT 1', 'PNM 1', 'RLW 1', 'RLW 2', 'RLW 3', 'ROD 1', 'ROD 2', 'SAT 1', 'SAT 2', 'SNT 1', 'SNT 2', 'SNT 3', 'TTL 1', 'TTL 2', 'TTL 3']*  
Char:  
*[725, 2880, 1236, 1674, 3410, 358, 3687, 3874, 390, 1644, 1670, 2770, 676, 3237, 4929, 3907, 2583, 627, 45, 3075, 229, 2172, 503, 1099, 309, 1633, 860, 355, 2066]*

**Attributions:**
- NICT Corpus - https://github.com/venali/BilingualCorpus