# NICT-2500 Info

**INFO**  
Lines: 2505
Japanese Words: 2917  
Japanese Char: 125303  
English Words: 67811  
English Char: 418122  

**Prompts**
GPT-3.5 Turbo: "translate <text> into English without explanation"
Gemini-1.5 Flash: "translate <text> into English without explanation"

**First Lines of the NICT Bilingual Corpus Matching This Criteria:**
- Max Lines: 2,500 (Margin of Error 15)
- Min Japanese Characters: 8
- Min English Words: 6
- Exclude lines with only names (Can tell because no hiragana characters--と and や and の not included, because on their own, they mean 'and' or 'of')
- Exclude lines with non-ASCII characters in the translation
  
Files:  
*['SCL 7', 'SCL 8', 'SCL 9', 'SCL 10', 'SCL 11', 'SCL 12', 'BDS 7', 'BDS 8', 'BLD 7', 'BLD 8', 'BLD 9', 'BLD 10', 'BLD 11', 'CLT 7', 'CLT 8', 'CLT 9', 'CLT 10', 'CLT 11', 'CLT 12', 'EPR 7', 'EPR 8', 'EPR 9', 'EPR 10', 'EPR 11', 'EPR 12', 'EPR 13', 'FML 7', 'FML 8', 'FML 9', 'FML 10', 'FML 11', 'FML 12', 'FML 13', 'GNM 7', 'HST 7', 'HST 8', 'HST 9', 'LTT 7', 'PNM 7', 'RLW 7', 'RLW 8', 'ROD 7', 'ROD 8', 'ROD 9', 'ROD 10', 'ROD 11', 'ROD 12', 'ROD 13', 'ROD 14', 'ROD 15', 'SAT 7', 'SAT 8', 'SAT 9', 'SAT 10', 'SNT 7', 'SNT 8', 'SNT 9', 'SNT 10', 'SNT 11', 'SNT 12', 'TTL 7', 'TTL 8', 'TTL 9', 'TTL 10', 'TTL 11', 'TTL 12']*  
Char:  
*[1362, 252, 1370, 1431, 366, 2734, 6583, 2012, 1322, 1328, 2205, 3101, 360, 545, 402, 2126, 990, 1059, 2267, 746, 1447, 2326, 1059, 1740, 1042, 1495, 1436, 987, 591, 855, 813, 1424, 1888, 7436, 3397, 3589, 2250, 7671, 9100, 8571, 230, 222, 350, 242, 2819, 1169, 647, 532, 1341, 198, 834, 1869, 1173, 4358, 578, 1783, 1269, 1819, 1524, 898, 2326, 2253, 1155, 3853, 143, 40]*

**Attributions:**
- NICT Corpus - https://github.com/venali/BilingualCorpus